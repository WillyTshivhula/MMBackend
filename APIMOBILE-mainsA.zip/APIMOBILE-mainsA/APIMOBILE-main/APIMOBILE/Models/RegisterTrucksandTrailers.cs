﻿public class Truck
{
    public int TruckId { get; set; }
    public string TruckType { get; set; }
    public string TruckMake { get; set; }
    public string TruckRegistration { get; set; }
    public string TruckModel { get; set; }
    public int TruckAxle { get; set; }
}

public class Trailer
{
    public int TrailerId { get; set; }
    public string Trailer1 { get; set; }
    public string Trailer2 { get; set; }
}

public class MiningDetails
{
    public int MiningDetailsId { get; set; }
    public string RequestType { get; set; }
    public string Site { get; set; }
}
