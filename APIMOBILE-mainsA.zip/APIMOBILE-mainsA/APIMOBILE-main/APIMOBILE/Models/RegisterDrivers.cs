﻿namespace APIMOBILE.Models.Transporter
{
    public class RegisterDrivers
    {
        public int Id { get; set; }
        public string FullName { get; set; }
        public string IDNo { get; set; }
        public string LicenseNo { get; set; }
        public string Transporter { get; set; }
        public string TruckReg { get; set; }
        public string Trailer1 { get; set; }
        public string Trailer2 { get; set; }
    }
}
