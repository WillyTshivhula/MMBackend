﻿using System;
using System.ComponentModel.DataAnnotations;

public class VehicleInspectionForm
{
    [Key] // This attribute specifies that the Id property is a primary key
    public int Id { get; set; }

    public string FullName { get; set; }

    public string Description { get; set; }

    public string Model { get; set; }

    public DateTime InspectionDate { get; set; }

    public string Status { get; set; }

    public string RejectReason { get; set; }
}
