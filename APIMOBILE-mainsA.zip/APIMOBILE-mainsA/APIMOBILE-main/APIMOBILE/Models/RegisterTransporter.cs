﻿namespace APIMOBILE.Models.Transporter
{
    public class RegisterTransporter
    {
        public int Id { get; set; }
        public string TransporterName { get; set; }
        public string RegistrationNumber { get; set; }
        public string VATNumber { get; set; }
        public string EmailAddress { get; set; }
        public string PhoneNumber { get; set; } // Approved or Rejected
        public string ContactPersonName { get; set; }
        public string ContactPersonSurname { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Address3 { get; set; }
        public string City { get; set; }
        public string Province { get; set; }
        public string PoastalCode { get; set; }
        public string Country { get; set; }
        public string DocumentType { get; set; }
        public string DocumentName { get; set; }
    }

}