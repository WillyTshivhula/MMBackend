﻿public class InspectionForm
{
    public int Id { get; set; }
    public string FullName { get; set; }
    public string Description { get; set; }
    public string Model { get; set; }
    public DateTime Date { get; set; }
    public string Status { get; set; } // Approved or Rejected
    public string RejectReason { get; set; } // Reason for rejection
}
