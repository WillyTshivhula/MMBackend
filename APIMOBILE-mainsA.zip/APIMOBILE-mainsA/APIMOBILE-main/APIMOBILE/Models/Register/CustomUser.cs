﻿using Microsoft.AspNetCore.Identity;
using System;
using System.ComponentModel.DataAnnotations;

namespace APIMOBILE.Models.Register
{
    public class CustomUser : IdentityUser<string>
    {

        [Required(ErrorMessage = "FirstName is required")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "LastName is required")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "CellphoneNumber is required")]
        public string CellphoneNumber { get; set; }

        [Required(ErrorMessage = "UserType is required")]
        public Roles UserType { get; set; }

        [Required(ErrorMessage = "Email Address is required")]
        [EmailAddress]

        public string UserName { get; set; }
        public override string Email { get => base.Email; set => base.Email = value; }


        [Required(ErrorMessage = "UserType is required")]
        public Roles UserTypes { get; set; }
    }



public enum Roles
    {
        Customer,
        Transporter,
        Marketer,
        Management,
        Logistics
    }
}
