﻿using System.ComponentModel.DataAnnotations;

namespace APIMOBILE.Models.Register
{
    public class RegisterUser
    {
        [Required(ErrorMessage = "First Name is required")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Last Name is required")]
        public string LastName { get; set; }

        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        [Required(ErrorMessage = "Email Address is required")]
        public string EmailAddress { get; set; }

        [Required(ErrorMessage = "Password is required")]
        [DataType(DataType.Password)]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$",
            ErrorMessage = "Password must be at least 8 characters long, contain one uppercase letter, one lowercase letter, one digit, and one special character.")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Cellphone Number is required")]
        public string CellphoneNumber { get; set; }

        [Required(ErrorMessage = "User Type is required")]
        public int UserType { get; set; }

        [Required(ErrorMessage = "Username is required")]
        public string UserName { get; set; }
    }
}
