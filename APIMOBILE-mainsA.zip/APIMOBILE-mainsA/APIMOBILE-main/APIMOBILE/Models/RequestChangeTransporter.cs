﻿namespace APIMOBILE.Models
{
    public class RequestChangeTransporter
    {
        public int Id { get; set; }
        public string RequestFor { get; set; }
        public string RequestedBy { get; set; }
        public string LineManager { get; set; }
        public string TypeofRequest { get; set; }
        public string RequestMotivation { get; set; }
    }
}