﻿using System;
using System.ComponentModel.DataAnnotations;

public class VehicleInspection
{
    [Key] 
    public int Id { get; set; }

    public string FullName { get; set; }
    public string Description { get; set; }
    public string Model { get; set; }
    public DateTime InspectionDate { get; set; }
}
