﻿// LoadingAdvice.cs

using System;

namespace APIMOBILE.Models
{
    public class LoadingAdviceTransporter
    {
        public int Id { get; set; }
        public string TripSchedule { get; set; }
        public string PurchaseOrderNumber { get; set; }
        public string OrderNumber { get; set; }
        public string Customer { get; set; }
        public string Transporter { get; set; }
        public string Driver { get; set; }
        public string Truck { get; set; }
        public string Trailer1 { get; set; }
        public string Trailer2 { get; set; }
        public string AxleConfiguration { get; set; }
        public string Product { get; set; }
        public string Site { get; set; }
        public DateTime ValidFrom { get; set; }
        public DateTime ValidTo { get; set; }
        public decimal Tonnage { get; set; }
        public string Comments { get; set; }
    }
}
