﻿using System.ComponentModel.DataAnnotations;

namespace APIMOBILE.Models.Login
{
    public class LoginUser
    {
        [Required(ErrorMessage = "Email address or cellphone number is required")]
        public string EmailOrCellphoneNumber { get; set; }

        [Required(ErrorMessage = "Password is required")]
        [DataType(DataType.Password)]
        public string? Password { get; set; }



    }
}


