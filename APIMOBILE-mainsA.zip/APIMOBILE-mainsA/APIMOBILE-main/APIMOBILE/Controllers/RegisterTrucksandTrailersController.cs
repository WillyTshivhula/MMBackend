﻿using APIMOBILE.Data;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/trucks")]
public class TruckController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public TruckController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpPost]
    public ActionResult<Truck> RegisterTruck(Truck truck)
    {
        _context.Trucks.Add(truck);
        _context.SaveChanges();
        return CreatedAtAction(nameof(RegisterTruck), new { id = truck.TruckId }, truck);
    }
}

[ApiController]
[Route("api/trailers")]
public class TrailerController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public TrailerController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpPost]
    public ActionResult<Trailer> RegisterTrailer(Trailer trailer)
    {
        _context.Trailers.Add(trailer);
        _context.SaveChanges();
        return CreatedAtAction(nameof(RegisterTrailer), new { id = trailer.TrailerId }, trailer);
    }
}

[ApiController]
[Route("api/mining")]
public class MiningDetailsController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public MiningDetailsController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpPost]
    public ActionResult<MiningDetails> AddMiningDetails(MiningDetails miningDetails)
    {
        _context.MiningDetails.Add(miningDetails);
        _context.SaveChanges();
        return CreatedAtAction(nameof(AddMiningDetails), new { id = miningDetails.MiningDetailsId }, miningDetails);
    }
}
