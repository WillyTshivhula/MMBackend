﻿using APIMOBILE.Data;
using Microsoft.AspNetCore.Mvc;
using APIMOBILE.Driver;

[ApiController]
[Route("api/loadingadvice")]
public class LoadingAdviceController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public LoadingAdviceController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetLoadingAdvice(int id)
    {
        var loadingAdvice = await _context.LoadingAdvices.FindAsync(id);

        if (loadingAdvice == null)
        {
            return NotFound();
        }

        return Ok(loadingAdvice);
    }
}

