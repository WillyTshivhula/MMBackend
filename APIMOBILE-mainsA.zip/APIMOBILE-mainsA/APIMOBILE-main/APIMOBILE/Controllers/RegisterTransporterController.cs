﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;
using APIMOBILE.Models.Transporter;
using APIMOBILE.Data;

namespace APIMOBILE.Controllers
{
    [Route("api/transporters")] // Base route for the API
    [ApiController]
    public class RegisterTransportersApiController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public RegisterTransportersApiController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/transporters
        [HttpGet]
        public async Task<ActionResult<IEnumerable<RegisterTransporter>>> GetTransporters()
        {
            return await _context.RegisterTransporter.ToListAsync();
        }

        // GET: api/transporters/5
        [HttpGet("{id}")]
        public async Task<ActionResult<RegisterTransporter>> GetTransporter(int id)
        {
            var transporter = await _context.RegisterTransporter.FindAsync(id);

            if (transporter == null)
            {
                return NotFound();
            }

            return transporter;
        }

        // POST: api/transporters
        [HttpPost]
        public async Task<ActionResult<RegisterTransporter>> RegisterTransporter(RegisterTransporter transporter)
        {
            if (ModelState.IsValid)
            {
                _context.RegisterTransporter.Add(transporter);
                await _context.SaveChangesAsync();
                return CreatedAtAction(nameof(GetTransporter), new { id = transporter.Id }, transporter);
            }

            return BadRequest(ModelState);
        }

        // PUT: api/transporters/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateTransporter(int id, RegisterTransporter transporter)
        {
            if (id != transporter.Id)
            {
                return BadRequest();
            }

            _context.Entry(transporter).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TransporterExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // DELETE: api/transporters/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTransporter(int id)
        {
            var transporter = await _context.RegisterTransporter.FindAsync(id);
            if (transporter == null)
            {
                return NotFound();
            }

            _context.RegisterTransporter.Remove(transporter);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool TransporterExists(int id)
        {
            return _context.RegisterTransporter.Any(e => e.Id == id);
        }
    }
}
