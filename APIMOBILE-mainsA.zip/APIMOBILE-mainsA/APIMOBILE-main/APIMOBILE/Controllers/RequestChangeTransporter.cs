﻿using APIMOBILE.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using APIMOBILE.Data;


using Microsoft.AspNetCore.Mvc;

using Microsoft.EntityFrameworkCore;

using APIMOBILE.Models;

using System.Collections.Generic;

using System.Linq;

using System.Threading.Tasks;
 
namespace APIMOBILE.Controllers

{

    [Route("api/[controller]")]

    [ApiController]

    public class RequestChangeController : ControllerBase

    {

        private readonly ApplicationDbContext _context; // Replace YourDbContext with the actual name of your DbContext

        public RequestChangeController(ApplicationDbContext context)

        {

            _context = context;

        }

        // GET: api/RequestChange

        [HttpGet]

        public async Task<ActionResult<IEnumerable<RequestChangeTransporter>>> GetChangeRequests()

        {

            // Return a list of change requests

            return await _context.RequestChangeTransporters.ToListAsync();

        }

        // GET: api/RequestChange/5

        [HttpGet("{id}")]

        public async Task<ActionResult<RequestChangeTransporter>> GetChangeRequest(int id)

        {

            var changeRequest = await _context.RequestChangeTransporters.FindAsync(id);

            if (changeRequest == null)

            {

                return NotFound();

            }

            return changeRequest;

        }

        // POST: api/RequestChange

        [HttpPost]

        public async Task<ActionResult<RequestChangeTransporter>> PostChangeRequest(RequestChangeTransporter changeRequest)

        {

            // Assuming you have some validation logic here before saving to the database

            _context.RequestChangeTransporters.Add(changeRequest);

            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetChangeRequest), new { id = changeRequest.Id }, changeRequest);

        }

        // PUT: api/RequestChange/5

        [HttpPut("{id}")]

        public async Task<IActionResult> PutChangeRequest(int id, RequestChangeTransporter changeRequest)

        {

            if (id != changeRequest.Id)

            {

                return BadRequest();

            }

            _context.Entry(changeRequest).State = EntityState.Modified;

            try

            {

                await _context.SaveChangesAsync();

            }

            catch (DbUpdateConcurrencyException)

            {

                if (!ChangeRequestExists(id))

                {

                    return NotFound();

                }

                else

                {

                    throw;

                }

            }

            return NoContent();

        }

        // DELETE: api/RequestChange/5

        [HttpDelete("{id}")]

        public async Task<IActionResult> DeleteChangeRequest(int id)

        {

            var changeRequest = await _context.RequestChangeTransporters.FindAsync(id);

            if (changeRequest == null)

            {

                return NotFound();

            }

            _context.RequestChangeTransporters.Remove(changeRequest);

            await _context.SaveChangesAsync();

            return NoContent();

        }

        private bool ChangeRequestExists(int id)

        {

            return _context.RequestChangeTransporters.Any(e => e.Id == id);

        }

    }

}
