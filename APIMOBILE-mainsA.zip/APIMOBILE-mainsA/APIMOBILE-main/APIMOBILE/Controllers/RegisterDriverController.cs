﻿// RegisterDriversController.cs

using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APIMOBILE.Models.Transporter;
using APIMOBILE.Data;

namespace APIMOBILE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegisterDriversController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public RegisterDriversController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/RegisterDrivers
        [HttpGet]
        public async Task<ActionResult<IEnumerable<RegisterDrivers>>> GetRegisterDrivers()
        {
            return await _context.RegisterDrivers.ToListAsync();
        }

        // GET: api/RegisterDrivers/5
        [HttpGet("{id}")]
        public async Task<ActionResult<RegisterDrivers>> GetRegisterDrivers(int id)
        {
            var registerDriver = await _context.RegisterDrivers.FindAsync(id);

            if (registerDriver == null)
            {
                return NotFound();
            }

            return registerDriver;
        }

        // POST: api/RegisterDrivers
        [HttpPost]
        public async Task<ActionResult<RegisterDrivers>> PostRegisterDrivers(RegisterDrivers registerDriver)
        {
            _context.RegisterDrivers.Add(registerDriver);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetRegisterDrivers", new { id = registerDriver.Id }, registerDriver);
        }

        // PUT: api/RegisterDrivers/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutRegisterDrivers(int id, RegisterDrivers registerDriver)
        {
            if (id != registerDriver.Id)
            {
                return BadRequest();
            }

            _context.Entry(registerDriver).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RegisterDriversExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // DELETE: api/RegisterDrivers/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteRegisterDrivers(int id)
        {
            var registerDriver = await _context.RegisterDrivers.FindAsync(id);
            if (registerDriver == null)
            {
                return NotFound();
            }

            _context.RegisterDrivers.Remove(registerDriver);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool RegisterDriversExists(int id)
        {
            return _context.RegisterDrivers.Any(e => e.Id == id);
        }
    }
}
