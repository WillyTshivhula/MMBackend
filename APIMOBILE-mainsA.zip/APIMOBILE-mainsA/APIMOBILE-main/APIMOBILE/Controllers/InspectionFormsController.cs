﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APIMOBILE.Models;
using APIMOBILE.Data;

[Route("api/[controller]")]
[ApiController]
public class InspectionFormsController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public InspectionFormsController(ApplicationDbContext context)
    {
        _context = context;
    }

    // GET: api/InspectionForms
    [HttpGet("all")]
    public async Task<ActionResult<IEnumerable<InspectionForm>>> GetInspectionForms()
    {
        try
        {
            return Ok(await _context.InspectionForms.ToListAsync());
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error retrieving InspectionForms: {ex.Message}");
            return StatusCode(500, "Internal server error");
        }
    }

    // GET: api/InspectionForms/5
    [HttpGet("{id:int}", Name = "GetInspectionFormById")]
    public async Task<ActionResult<InspectionForm>> GetInspectionFormById(int id)
    {
        try
        {
            var inspectionForm = await _context.InspectionForms.FindAsync(id);

            if (inspectionForm == null)
            {
                return NotFound();
            }

            return inspectionForm;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error retrieving InspectionForm with ID {id}: {ex.Message}");
            return StatusCode(500, "Internal server error");
        }
    }

    // POST: api/InspectionForms
    [HttpPost]
    public async Task<ActionResult<InspectionForm>> PostInspectionForm(InspectionForm form)
    {
        try
        {
            _context.InspectionForms.Add(form);
            await _context.SaveChangesAsync();

            return CreatedAtRoute("GetInspectionFormById", new { id = form.Id }, form);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error creating InspectionForm: {ex.Message}");
            return StatusCode(500, "Internal server error");
        }
    }

    // PUT: api/InspectionForms/5
    [HttpPut("{id:int}")]
    public async Task<IActionResult> PutInspectionForm(int id, InspectionForm updatedForm)
    {
        try
        {
            if (id != updatedForm.Id)
            {
                return BadRequest();
            }

            var existingForm = await _context.InspectionForms.FindAsync(id);
            if (existingForm == null)
            {
                return NotFound();
            }

            existingForm.FullName = updatedForm.FullName;
            existingForm.Description = updatedForm.Description;
            existingForm.Model = updatedForm.Model;
            existingForm.Date = updatedForm.Date;
            existingForm.Status = updatedForm.Status;
            existingForm.RejectReason = updatedForm.RejectReason;

            await _context.SaveChangesAsync();

            return NoContent();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error updating InspectionForm with ID {id}: {ex.Message}");
            return StatusCode(500, "Internal server error");
        }
    }

    // DELETE: api/InspectionForms/5
    [HttpDelete("{id:int}")]
    public async Task<IActionResult> DeleteInspectionForm(int id)
    {
        try
        {
            var inspectionForm = await _context.InspectionForms.FindAsync(id);
            if (inspectionForm == null)
            {
                return NotFound();
            }

            _context.InspectionForms.Remove(inspectionForm);
            await _context.SaveChangesAsync();

            return NoContent();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error deleting InspectionForm with ID {id}: {ex.Message}");
            return StatusCode(500, "Internal server error");
        }
    }
}
