﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APIMOBILE.Data;

namespace YourNamespace.Controllers // Update with the correct namespace for your controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProfileController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public ProfileController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/Profile
        [HttpGet("all")]
        public async Task<ActionResult<IEnumerable<Profile>>> GetProfiles()
        {
            try
            {
                return await _context.Profiles.ToListAsync();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving profiles: {ex.Message}");
                return StatusCode(500, "Internal server error");
            }
        }

        // GET: api/Profile/5
        [HttpGet("{id:int}", Name = "GetProfileById")]
        public async Task<ActionResult<Profile>> GetProfileById(int id)
        {
            try
            {
                var profile = await _context.Profiles.FindAsync(id);

                if (profile == null)
                {
                    return NotFound();
                }

                return profile;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving profile with ID {id}: {ex.Message}");
                return StatusCode(500, "Internal server error");
            }
        }

        // POST: api/Profile
        [HttpPost]
        public async Task<ActionResult<Profile>> PostProfile(Profile profile)
        {
            try
            {
                _context.Profiles.Add(profile);
                await _context.SaveChangesAsync();

                return CreatedAtRoute("GetProfileById", new { id = profile.Id }, profile);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error creating profile: {ex.Message}");
                return StatusCode(500, "Internal server error");
            }
        }

        // PUT: api/Profile/5
        [HttpPut("{id:int}")]
        public async Task<IActionResult> PutProfile(int id, Profile updatedProfile)
        {
            try
            {
                if (id != updatedProfile.Id)
                {
                    return BadRequest();
                }

                _context.Entry(updatedProfile).State = EntityState.Modified;

                await _context.SaveChangesAsync();

                return NoContent();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating profile with ID {id}: {ex.Message}");
                return StatusCode(500, "Internal server error");
            }
        }

        // DELETE: api/Profile/5
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DeleteProfile(int id)
        {
            try
            {
                var profile = await _context.Profiles.FindAsync(id);
                if (profile == null)
                {
                    return NotFound();
                }

                _context.Profiles.Remove(profile);
                await _context.SaveChangesAsync();

                return NoContent();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error deleting profile with ID {id}: {ex.Message}");
                return StatusCode(500, "Internal server error");
            }
        }

        private bool ProfileExists(int id)
        {
            return _context.Profiles.Any(e => e.Id == id);
        }
    }
}
