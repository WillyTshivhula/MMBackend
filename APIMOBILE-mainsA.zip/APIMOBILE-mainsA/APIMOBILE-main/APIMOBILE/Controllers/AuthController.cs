﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using APIMOBILE.Models.Register;
using APIMOBILE.Models.Login;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace APIMOBILE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private readonly UserManager<CustomUser> _userManager;
        private readonly SignInManager<CustomUser> _signInManager;

        public AuthenticationController(UserManager<CustomUser> userManager, SignInManager<CustomUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }

        [HttpPost]
        [Route("Register")]
        public async Task<IActionResult> Register(RegisterUser model)
        {
            if (ModelState.IsValid)
            {
                var user = new CustomUser
                {
                    FirstName = model.FirstName,
                    UserName = model.UserName,
                    LastName = model.LastName,
                    Email = model.EmailAddress,
                    CellphoneNumber = model.CellphoneNumber,
                    UserType = (Roles)model.UserType, // Explicitly cast UserType to Roles enum
                };
                try
                {
                    var result = await _userManager.CreateAsync(user, model.Password);

                    if (result.Succeeded)
                    {
                        return Ok("Registration successful.");
                    }
                    else
                    {
                        foreach (var error in result.Errors)
                        {
                            ModelState.AddModelError("", error.Description);
                        }

                        return BadRequest(ModelState);
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", $"Exception during registration: {ex.Message}");
                    return StatusCode(500, ModelState);
                }
            }
            else
            {
                return BadRequest(ModelState);
            }
        }

        [HttpPost]
        [Route("Login")]
        public async Task<IActionResult> Login(LoginUser model)
        {
            if (ModelState.IsValid)
            {
                CustomUser user = null;

                if (model.EmailOrCellphoneNumber != null && model.EmailOrCellphoneNumber.Contains("@"))
                {
                    user = await _userManager.FindByEmailAsync(model.EmailOrCellphoneNumber);
                }
                else if (model.EmailOrCellphoneNumber != null)
                {
                    user = await _userManager.FindByNameAsync(model.EmailOrCellphoneNumber);
                }

                if (user != null)
                {
                    var result = await _signInManager.PasswordSignInAsync(user, model.Password, false, false);

                    if (result.Succeeded)
                    {
                        return Ok("Login successful.");
                    }
                }

                return BadRequest("Invalid login attempt. Please check your credentials.");
            }

            return BadRequest("Invalid login data.");
        }

        [HttpGet]
        [Route("GetUsers")]
        public IActionResult GetUsers()
        {
            try
            {
                var users = _userManager.Users.Select(user => new
                {
                    user.FirstName,
                    user.LastName,
                    user.Email,
                    user.CellphoneNumber,
                    user.UserType
                });

                return Ok(users);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while retrieving users: {ex.Message}");
            }
        }
    }
}
