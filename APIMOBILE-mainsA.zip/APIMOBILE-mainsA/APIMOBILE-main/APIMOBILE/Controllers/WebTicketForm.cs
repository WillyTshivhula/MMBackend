﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore; // Add this namespace
using APIMOBILE.Data;

namespace APIMOBILE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WebTicketFormController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public WebTicketFormController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        [Route("CreateWebTicketForm")]
        public async Task<IActionResult> CreateWebTicketForm(WebTicketForm form)
        {
            try
            {
                _context.WebTicketForm.Add(form);
                await _context.SaveChangesAsync();
                return Ok("Web Ticket Form created successfully.");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", $"Exception during Web Ticket Form creation: {ex.Message}");
                return StatusCode(500, ModelState);
            }
        }

        [HttpGet]
        [Route("GetWebTicketForms")]
        public async Task<ActionResult<IEnumerable<WebTicketForm>>> GetWebTicketForms()
        {
            return await _context.WebTicketForm.ToListAsync();
        }
    }
}
