﻿// LoadingAdviceController.cs

using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APIMOBILE.Models;
using APIMOBILE.Data;

namespace APIMOBILE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoadingAdviceController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public LoadingAdviceController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/LoadingAdvice
        [HttpGet("all")] // Use a more specific route
        public async Task<ActionResult<IEnumerable<LoadingAdviceTransporter>>> GetLoadingAdvice()
        {
            try
            {
                return await _context.LoadingAdvice.ToListAsync();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving LoadingAdvice: {ex.Message}");
                return StatusCode(500, "Internal server error");
            }
        }

        // GET: api/LoadingAdvice/5
        [HttpGet("{id:int}", Name = "GetLoadingAdviceById")] // Use a more specific route and restrict id to int
        public async Task<ActionResult<LoadingAdviceTransporter>> GetLoadingAdviceById(int id)
        {
            try
            {
                var loadingAdvice = await _context.LoadingAdvice.FindAsync(id);

                if (loadingAdvice == null)
                {
                    return NotFound();
                }

                return loadingAdvice;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving LoadingAdvice with ID {id}: {ex.Message}");
                return StatusCode(500, "Internal server error");
            }
        }

        // POST: api/LoadingAdvice
        [HttpPost]
        public async Task<ActionResult<LoadingAdviceTransporter>> PostLoadingAdvice(LoadingAdviceTransporter loadingAdvice)
        {
            try
            {
                _context.LoadingAdvice.Add(loadingAdvice);
                await _context.SaveChangesAsync();

                return CreatedAtRoute("GetLoadingAdviceById", new { id = loadingAdvice.Id }, loadingAdvice);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error creating LoadingAdvice: {ex.Message}");
                return StatusCode(500, "Internal server error");
            }
        }

        // PUT: api/LoadingAdvice/5
        [HttpPut("{id:int}")]
        public async Task<IActionResult> PutLoadingAdvice(int id, LoadingAdviceTransporter loadingAdvice)
        {
            try
            {
                if (id != loadingAdvice.Id)
                {
                    return BadRequest();
                }

                _context.Entry(loadingAdvice).State = EntityState.Modified;

                await _context.SaveChangesAsync();

                return NoContent();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating LoadingAdvice with ID {id}: {ex.Message}");
                return StatusCode(500, "Internal server error");
            }
        }

        // DELETE: api/LoadingAdvice/5
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DeleteLoadingAdvice(int id)
        {
            try
            {
                var loadingAdvice = await _context.LoadingAdvice.FindAsync(id);
                if (loadingAdvice == null)
                {
                    return NotFound();
                }

                _context.LoadingAdvice.Remove(loadingAdvice);
                await _context.SaveChangesAsync();

                return NoContent();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error deleting LoadingAdvice with ID {id}: {ex.Message}");
                return StatusCode(500, "Internal server error");
            }
        }

        private bool LoadingAdviceExists(int id)
        {
            return _context.LoadingAdvice.Any(e => e.Id == id);
        }
    }
}
