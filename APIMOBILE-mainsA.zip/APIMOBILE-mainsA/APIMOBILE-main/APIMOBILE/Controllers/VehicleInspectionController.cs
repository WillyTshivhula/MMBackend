﻿using APIMOBILE.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIMOBILE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VehicleInspectionController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public VehicleInspectionController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        [Route("CreateVehicleInspection")]
        public async Task<IActionResult> CreateVehicleInspection(VehicleInspectionForm form)
        {
            try
            {
                _context.VehicleInspectionForm.Add(form); // Corrected the typo here
                await _context.SaveChangesAsync();
                return Ok("Vehicle Inspection Form created successfully.");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", $"Exception during Vehicle Inspection Form creation: {ex.Message}");
                return StatusCode(500, ModelState);
            }
        }

        [HttpGet]
        [Route("GetVehicleInspectionForms")]
        public async Task<ActionResult<IEnumerable<VehicleInspectionForm>>> GetVehicleInspectionForms()
        {
            return await _context.VehicleInspectionForm.ToListAsync(); 
        }
    }
}
