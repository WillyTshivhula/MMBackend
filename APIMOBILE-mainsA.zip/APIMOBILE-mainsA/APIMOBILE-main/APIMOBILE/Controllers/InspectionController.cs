﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APIMOBILE.Data;

[Route("api/[controller]")]
[ApiController]
public class InspectionController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public InspectionController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpPost("schedule")]
    public async Task<IActionResult> ScheduleInspection([FromBody] VehicleInspection inspection)
    {
        try
        {
            if (inspection == null)
            {
                return BadRequest("Invalid inspection data");
            }

            _context.Inspections.Add(inspection);
            await _context.SaveChangesAsync();

            return CreatedAtRoute(nameof(ViewInspectionById), new { id = inspection.Id }, inspection);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error scheduling inspection: {ex.Message}");
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpGet("view")]
    public async Task<ActionResult<IEnumerable<VehicleInspection>>> ViewInspections()
    {
        try
        {
            return Ok(await _context.Inspections.ToListAsync());
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error retrieving inspections: {ex.Message}");
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpGet("{id:int}", Name = "ViewInspectionById")]
    public async Task<ActionResult<VehicleInspection>> ViewInspectionById(int id)
    {
        try
        {
            var inspection = await _context.Inspections.FindAsync(id);

            if (inspection == null)
            {
                return NotFound();
            }

            return inspection;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error retrieving inspection with ID {id}: {ex.Message}");
            return StatusCode(500, "Internal server error");
        }
    }
}
