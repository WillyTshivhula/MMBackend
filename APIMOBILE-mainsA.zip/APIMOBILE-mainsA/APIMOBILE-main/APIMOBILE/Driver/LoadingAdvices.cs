﻿using System;
using System.ComponentModel.DataAnnotations;


namespace APIMOBILE.Driver
{
    public class LoadingAdvices
    {
        public int Id { get; set; }

        // Trip/schedule information
        [Display(Name = "Trip/schedule No")]
        public string TripScheduleNumber { get; set; }

        [Display(Name = "Order number")]
        public string OrderNumber { get; set; }

        [Display(Name = "Purchase Order number")]
        public string PurchaseOrderNumber { get; set; }

        public string Site { get; set; }

        public string Transporter { get; set; }

        public string Customer { get; set; }

        public string Product { get; set; }

        public string Driver { get; set; }

        public string Truck { get; set; }

        [Display(Name = "ID Number")]
        public string IdNumber { get; set; }

        [Display(Name = "Trailer 1")]
        public string Trailer1 { get; set; }

        [Display(Name = "Trailer 2")]
        public string Trailer2 { get; set; }

        [Display(Name = "Axle configuration")]
        public string AxleConfiguration { get; set; }

        [Display(Name = "Valid from")]
        public DateTime ValidFrom { get; set; }

        [Display(Name = "Valid to")]
        public DateTime ValidTo { get; set; }

        public string Status { get; set; }

        [Display(Name = "Created on")]
        public DateTime CreatedOn { get; set; }

        [Display(Name = "Comment")]
        public string Comment { get; set; }

        // Movement summary
        [Display(Name = "Tonnages allocated")]
        public decimal TonnagesAllocated { get; set; }

        [Display(Name = "Tonnages remaining to collect")]
        public decimal TonnagesRemainingToCollect { get; set; }

        [Display(Name = "Tonnages collected")]
        public decimal TonnagesCollected { get; set; }
    }

}
