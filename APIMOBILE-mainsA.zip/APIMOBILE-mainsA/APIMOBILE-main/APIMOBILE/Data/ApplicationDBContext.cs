﻿using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using APIMOBILE.Models.Register;
using Microsoft.AspNetCore.Identity;
using APIMOBILE.Driver;
using APIMOBILE.Models.Transporter;
using APIMOBILE.Models;

namespace APIMOBILE.Data
{
    public class ApplicationDbContext : IdentityDbContext<CustomUser, IdentityRole, string>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

      
        public DbSet<CustomUser> Users { get; set; }
        public DbSet<LoadingAdvices> LoadingAdvices { get; set; }
        public DbSet<Profile>? Profiles { get; set; }
        public DbSet<InspectionForm> InspectionForms { get; set; }
        public DbSet<WebTicketForm> WebTicketForm { get; set; }


        public DbSet<VehicleInspectionForm> VehicleInspectionForm{ get; set; }

        public DbSet<RegisterTransporter> RegisterTransporter { get; set; }
        public DbSet<Truck> Trucks { get; set; }
        public DbSet<Trailer> Trailers { get; set; }
        public DbSet<MiningDetails> MiningDetails { get; set; }
        public DbSet<RegisterDrivers> RegisterDrivers { get; set; }

        public DbSet<RequestChangeTransporter> RequestChangeTransporters { get; set; }

        public DbSet<VehicleInspection> Inspections { get; set; }

        public DbSet<LoadingAdviceTransporter> LoadingAdvice { get; set; }



        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<CustomUser>()
                .HasIndex(u => u.Email)
                .IsUnique();

            modelBuilder.Entity<VehicleInspectionForm>().HasKey(v => v.Id);
         //   modelBuilder.Entity<VehicleInspection>().HasNoKey();

            
        }
    }
}
